import { Component, OnInit } from '@angular/core';
import { FormComponent } from '../form/form.component';

@Component({
  selector: 'app-data',
  templateUrl: './data.component.html',
  styleUrls: ['./data.component.css']
})
export class DataComponent implements OnInit {

  constructor() { }

  listdata=Array();
  

  ngOnInit(): void {
    
    this.listdata=JSON.parse(localStorage.getItem('studentdata') || '{}');

    // for(let i=0;i<this.listdata.length;i++){
    //   console.log(this.listdata[i]);
    // }
    
  

  }
  onDelete(id:any){
    this.listdata.splice(id, 1);
    localStorage.setItem('studentdata',JSON.stringify(this.listdata));

  }
  
  

}




