import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {
 
  enrollform:any;
  listdata: any;
  submitted = false;
  section: any=['A','B','C'];
 



  constructor(private fb: FormBuilder, private router: Router) {

    this.listdata=[];
    this.enrollform=this.fb.group({

      "name":new FormControl(null,[Validators.required]),
      "email":new FormControl(null,[Validators.required]),
      "dept":new FormControl(null,[Validators.required]),
      "sec":new FormControl(null,[Validators.required])
    

    });
    

    
  }

 
  ngOnInit(): void {

    this.enrollform=new FormGroup({

      "name":new FormControl(null,[Validators.required]),
      "email":new FormControl(null,[Validators.required]),
      "dept":new FormControl(null,[Validators.required]),
      "sec":new FormControl(null,[Validators.required])
    

    })
   
  
  }

  get f() {return this.enrollform.controls}
  

  public submitData(): void
  {
    this.submitted=true;

    if(this.enrollform.invalid){
      return;
    }
    
    this.listdata.push(this.enrollform.value);
    localStorage.setItem("studentdata", JSON.stringify(this.listdata));
    this.enrollform.reset();

    Swal.fire({  
      position: 'top',  
      icon: 'success',  
      title: 'DATA IS SUCESSFULLY STORED',  
       
      
    })  
    
    
    
    


  }

  // get name() {return this.enrollform.get('name')}  
  // get email() {return this.enrollform.get('email')} 
  // get dept() {return this.enrollform.get('dept')} 
  // get sec() {return this.enrollform.get('sec')} 


  }